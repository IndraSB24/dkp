<header class="page-header">
    <style>
        .myinput{
			width:100%;
			height:auto;
			border:0px solid #000;
			border-radius:0px; 
			-moz-border-radius:8px;
			margin-left:0px;
			padding:13px 10px;
            line-height:100%;
		}
    </style>
</header>

<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <form method="POST" action="<?= base_url(); ?>/formula_produk/tambah">
                            <div class=" form-group">
                                <label for="produk">Nama Produk</label>
                                <select class="form-control" id="produk" name="produk">
                                    <option disabled selected>Pilih Nama Produk</option>
                                    <?php foreach ($list_produk as $row) : ?>
                                        <option value="<?= $row['id'] ?>"><?= $row['nama'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <?= form_error('kategori', '<small class="form-text text-danger">', '</small>'); ?>
                            </div>
                            <div class=" form-group">
                                <label for="resep">List Formula Produk</label>
                                <table id="tbl_detail_resep" style="font-family:nunito; font-color:black; font-size:15px" border="1" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="bg-primary" style="text-align:center; color:white;" bgcolor="#b7d5ac" width="70%"> Bahan </th>
                                            <th class="bg-primary" style="text-align:center; color:white;" bgcolor="#b7d5ac" width="15%"> Jumlah </th>
                                            <th class="bg-primary" style="text-align:center; color:white;" bgcolor="#b7d5ac" width="15%"> Satuan Dasar </th>
                                        </tr>
                                    </thead>
                                    <tbody>
            							<?php
            								$itung = 1;
            								for($x=1;$x<=5;$x++){
            									$itung = $x;
            							?>
            								<tr>
                                                <td>
                                                    <input type="hidden" id="<?= 'val_bahan_'.$x ?>" name="<?= 'val_bahan_'.$x ?>" />
                                                    <select class="form-control select2" id="<?= 'bahan_'.$x ?>" name="<?= 'bahan_'.$x ?>">
                                                        <option disabled selected>Pilih Bahan</option>
                                                        <?php foreach ($list_bahan as $row) : 
                                                            echo '<option value=" '.$row['id'].'PengHubunG'.$row['satuan_dasar'].'PengHubunG'.$x.'"> '.$row['nama'].'</option>';
                                                        endforeach; ?> 
                                                    </select>
                                                </td>
                                                <td>
                                                    <input class="myinput" type="number" id="<?= 'jumlah_'.$x ?>" name="<?= 'jumlah_'.$x ?>" style="width:100%; text-align:center">
                                                </td>
                                                <td>
                                                    <input class="myinput" type="text" id="<?= 'satuan_'.$x ?>" style="width:100%; text-align:center" readonly>
                                                </td>
                                            </tr>
            							<?php } ?>
                                    </tbody>
            			        </table>
            			        <button type="button" onclick="tambahRow()">Tambah Baris</button>
        			        </div>
        			        <br>
        			        <input type="hidden" id="itung" name="itung" value="<?= $itung ?>">
                            <a href="<?= base_url(); ?>formula_produk/formula_produk" class="btn btn-danger">Kembali</a>
                            <button type="submit" class="btn btn-primary float-right">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>


<script>
    let itung_all;
	document.addEventListener('DOMContentLoaded', function() {
	    if(itung_all != ""){
	        document.getElementById('itung').value = 5;
	    }
	    var itung = $('#itung').val();
	    itung_all = itung;
	    
	    for(i=1; i<=itung; i++){
    		Array.prototype.forEach.call(document.getElementsByName('bahan_'+i),
    		function (elem) {
    			elem.addEventListener('change', function() {
    				let text	= this.value;
    				const isi 	= text.split("PengHubunG");
    				let id		= isi[0],
    					satuan 	= isi[1],
    					row     = isi[2];
    				
    				document.getElementById('satuan_'+row).value = satuan;
    				document.getElementById('val_bahan_'+row).value = id;
    			});
    		});
	    };
	})

    function tambahRow() {
        var table   = document.getElementById("tbl_detail_resep");
        var baris   = parseInt(itung_all) + 1;
        itung_all   = baris;
        
        var row     = table.insertRow(baris);
        var cell1   = row.insertCell(0);
        var cell2   = row.insertCell(1);
        var cell3   = row.insertCell(2);
        cell1.innerHTML =   "<input type='hidden' id='val_bahan_"+baris+"' name='val_bahan_"+baris+"' />"+
                            "<select class='form-control select2' id='bahan_"+baris+"' name='bahan_"+baris+"'>"+
                                "<option disabled selected>Pilih Bahan</option>"+
                                "<?php foreach ($list_bahan as $row) : ?> "+
                                    "<option value='<?=$row['id']?>PengHubunG<?=$row['satuan_dasar']?>PengHubunG"+baris+"'> <?= $row['nama'] ?><?=$row['id']?>PengHubunG<?=$row['satuan_dasar']?>PengHubunG"+baris+" </option>"+
                                "<?php endforeach; ?>"+
                            "</select>";
        cell2.innerHTML =   "<input class='myinput' type='number' id='jumlah_"+baris+"' name='jumlah_"+baris+"' style='width:100%; text-align:center'>";
        cell3.innerHTML =   "<input class='myinput' type='text' id='satuan_"+baris+"' style='width:100%; text-align:center' value='satuan_"+baris+"' readonly>";
        
        document.addEventListener('DOMContentLoaded', function() {
    	    document.getElementById('itung').value = baris;
    	})
    	
    	
    }

</script>

